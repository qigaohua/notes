return {
  type_3 = {
    index = 2,
    sub_type_1 = {
      my = "aaa",
    },
    type = "420",
  },
  fps = 10,
  yuv_path = "/tmp/yuv",
  source_buffer = 1,
  md_source_type = "yuv",
  type_2 = {
    index = 2,
    sub_type_1 = {
      my = "bbb",
    },
    type = "420",
  },
  dump_yuv_enable = false,
  max_files = 50,
  jpeg_path = "/tmp/jpeg",
  type_1 = {
    index = 1,
    type = "422",
  },
  md_enable = false,
}