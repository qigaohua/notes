#include <stdio.h>



void m3_a_p1()
{
    printf("===>>   m3-a-p1\n");
}

void m3_a_p2()
{
    printf("===>>   m3-a-p2\n");
}

void m3_a_p3()
{
    printf("===>>   m3-a-p3\n");
}
