#include <stdio.h>



void m2_a_p1()
{
    printf("===>>   m2-a-p1\n");
}

void m2_a_p2()
{
    printf("===>>   m2-a-p2\n");
}

void m2_a_p3()
{
    printf("===>>   m2-a-p3\n");
}
