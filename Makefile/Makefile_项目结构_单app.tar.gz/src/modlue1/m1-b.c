#include <stdio.h>



void m1_b_p1()
{
    printf("===>>   m1-b-p1\n");
}

void m1_b_p2()
{
    printf("===>>   m1-b-p2\n");
}

void m1_b_p3()
{
    printf("===>>   m1-b-p3\n");
}
