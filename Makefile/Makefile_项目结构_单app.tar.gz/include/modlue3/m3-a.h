#ifndef _m3_a_h_
#define _m3_a_h_

void m3_a_p1();
void m3_a_p2();
void m3_a_p3();

#endif
