#include <stdio.h>



void m3_b_p1()
{
    printf("===>>   m3-b-p1\n");
}

void m3_b_p2()
{
    printf("===>>   m3-b-p2\n");
}

void m3_b_p3()
{
    printf("===>>   m3-b-p3\n");
}
