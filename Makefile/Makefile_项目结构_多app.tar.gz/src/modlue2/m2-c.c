#include <stdio.h>



void m2_c_p1()
{
    printf("===>>   m2-c-p1\n");
}

void m2_c_p2()
{
    printf("===>>   m2-c-p2\n");
}

void m2_c_p3()
{
    printf("===>>   m2-c-p3\n");
}
