#include <stdio.h>


#include "../include/modlue1/m1-c.h"
#include "../include/modlue2/m2-c.h"
#include "../include/modlue3/m3-c.h"


void main_test_p()
{
    printf("===>> main_test_p\n");
    m1_c_p1();
    m2_c_p1();
    m3_c_p1();
}
