#ifndef _m1_c_h_
#define _m1_c_h_

void m1_c_p1();
void m1_c_p2();
void m1_c_p3();

#endif
