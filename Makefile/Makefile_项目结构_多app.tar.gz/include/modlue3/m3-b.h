#ifndef _m3_b_h_
#define _m3_b_h_

void m3_b_p1();
void m3_b_p2();
void m3_b_p3();

#endif
