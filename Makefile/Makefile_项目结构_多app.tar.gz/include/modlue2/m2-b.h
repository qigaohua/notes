#ifndef _m2_b_h_
#define _m2_b_h_

void m2_b_p1();
void m2_b_p2();
void m2_b_p3();

#endif
