#ifndef _m2_a_h_
#define _m2_a_h_

void m2_a_p1();
void m2_a_p2();
void m2_a_p3();

#endif
