#ifndef _m2_c_h_
#define _m2_c_h_

void m2_c_p1();
void m2_c_p2();
void m2_c_p3();

#endif
