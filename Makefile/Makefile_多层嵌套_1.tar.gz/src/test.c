#include <stdio.h>



void main_test_p()
{
    printf("===>> main_test_p\n");
}
