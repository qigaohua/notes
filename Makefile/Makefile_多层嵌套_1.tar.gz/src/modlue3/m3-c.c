#include <stdio.h>



void m3_c_p1()
{
    printf("===>>   m3-c-p1\n");
}

void m3_c_p2()
{
    printf("===>>   m3-c-p2\n");
}

void m3_c_p3()
{
    printf("===>>   m3-c-p3\n");
}
