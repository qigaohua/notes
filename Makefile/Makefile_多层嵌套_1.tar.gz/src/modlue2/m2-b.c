#include <stdio.h>



void m2_b_p1()
{
    printf("===>>   m2-b-p1\n");
}

void m2_b_p2()
{
    printf("===>>   m2-b-p2\n");
}

void m2_b_p3()
{
    printf("===>>   m2-b-p3\n");
}
