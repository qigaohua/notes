#include <stdio.h>



void m1_c_p1()
{
    printf("===>>   m1-c-p1\n");
}

void m1_c_p2()
{
    printf("===>>   m1-c-p2\n");
}

void m1_c_p3()
{
    printf("===>>   m1-c-p3\n");
}
