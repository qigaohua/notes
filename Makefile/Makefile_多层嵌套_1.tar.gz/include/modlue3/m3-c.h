#ifndef _m3_c_h_
#define _m3_c_h_

void m3_c_p1();
void m3_c_p2();
void m3_c_p3();

#endif
