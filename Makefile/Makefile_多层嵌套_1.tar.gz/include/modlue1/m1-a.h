#ifndef _m1_a_h_
#define _m1_a_h_

void m1_a_p1();
void m1_a_p2();
void m1_a_p3();

#endif
